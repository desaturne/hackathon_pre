import cv2
import os
import torch
import openai
from ultralytics import YOLO
from moviepy import VideoFileClip, CompositeVideoClip, AudioFileClip
from openai import OpenAI
import ffmpeg

# --- CONFIG ---
VIDEO_PATH = "videoplayback.mp4"
FRAME_RATE = 1  # Extract 1 frame per second
TMP_AUDIO_FOLDER = "tts_audio"
client = OpenAI(api_key="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")

# --- Load YOLOv8 model ---
model = YOLO("yolov8n.pt")

# --- Create temp folder for TTS ---
os.makedirs(TMP_AUDIO_FOLDER, exist_ok=True)

# --- Step 1: Extract frames ---
cap = cv2.VideoCapture(VIDEO_PATH)
fps = cap.get(cv2.CAP_PROP_FPS)
frame_interval = int(fps // FRAME_RATE) if fps > 0 else 1

frames = []
timestamps = []
frame_id = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break
    if frame_id % frame_interval == 0:
        frames.append(frame)
        timestamps.append(frame_id / fps)
    frame_id += 1

cap.release()
print(f"✅ Extracted {len(frames)} frames")

# --- Step 2: Run YOLOv8 Detection ---
events = []
for i, frame in enumerate(frames):
    results = model(frame)[0]
    class_ids = results.boxes.cls.cpu().numpy().astype(int)
    class_names = [model.names[c] for c in class_ids]
    if class_names:
        events.append({
            "timestamp": timestamps[i],
            "objects": class_names,
            "description": f"Detected: {', '.join(class_names)}"
        })
print(f"✅ Found {len(events)} notable events")

# --- Step 3: Generate commentary via GPT ---
def generate_commentary(description, time):
    prompt = f"You're a lively sports commentator. Describe this scene with enthusiasm: {description} at {time:.1f} seconds."
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message['content']

commentary = []
for i, event in enumerate(events):
    text = generate_commentary(event['description'], event['timestamp'])
    commentary.append({
        "timestamp": event["timestamp"],
        "text": text
    })
    print(f"🗣️  [{event['timestamp']:.1f}s] {text}")

# --- Step 4: Convert commentary to audio using OpenAI TTS ---
audio_paths = []
for i, line in enumerate(commentary):
    tts_response = client.audio.speech.create(
        model="tts-1",
        voice="nova",
        input=line["text"]
    )
    audio_path = os.path.join(TMP_AUDIO_FOLDER, f"line_{i}.mp3")
    tts_response.stream_to_file(audio_path)
    audio_paths.append((line["timestamp"], audio_path))

print("✅ Generated TTS audio")

# --- Step 5: Overlay audio onto original video ---
# Merge all audio clips into one final track aligned with timestamps
inputs = []
filters = []
for idx, (timestamp, path) in enumerate(audio_paths):
    inputs.extend(['-itsoffset', str(timestamp), '-i', path])
    filters.append(f'[{idx + 1}:a]')

concat_filter = f"{''.join(filters)}concat=n={len(filters)}:v=0:a=1[outa]"

cmd = ['ffmpeg', '-y', '-i', VIDEO_PATH] + inputs + [
    '-filter_complex', concat_filter,
    '-map', '0:v', '-map', '[outa]',
    '-c:v', 'copy',
    '-shortest',
    'output_with_commentary.mp4'
]
os.system(" ".join(cmd))

print("🎬 Final video saved as: output_with_commentary.mp4")
