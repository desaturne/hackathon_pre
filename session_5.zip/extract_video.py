import os
import cv2
import subprocess
import requests
from ultralytics import YOLO
from TTS.api import TTS

# --- CONFIG ---
VIDEO_PATH = "football.mp4"
FRAME_RATE = 1
TMP_AUDIO_FOLDER = "tts_audio"
OUTPUT_VIDEO = "output_with_commentary.mp4"
OLLAMA_MODEL = "mistral"

# --- SETUP ---
os.makedirs(TMP_AUDIO_FOLDER, exist_ok=True)

# Use robust VITS model (handles short text better)
tts = TTS(model_name="tts_models/en/vctk/vits", progress_bar=False)

# YOLOv8 for object detection
model = YOLO("yolov8n.pt")

# --- STEP 1: Extract frames ---
cap = cv2.VideoCapture(VIDEO_PATH)
fps = cap.get(cv2.CAP_PROP_FPS)
interval = int(fps // FRAME_RATE) if fps > 0 else 1
frames, timestamps = [], []
frame_id = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break
    if frame_id % interval == 0:
        frames.append(frame)
        timestamps.append(frame_id / fps)
    frame_id += 1
cap.release()
print(f"✅ Extracted {len(frames)} frames")

# --- STEP 2: Detect objects ---
events = []
for i, frame in enumerate(frames):
    results = model(frame)[0]
    class_ids = results.boxes.cls.cpu().numpy().astype(int)
    class_names = [model.names[c] for c in class_ids]
    if class_names:
        events.append({
            "timestamp": timestamps[i],
            "objects": class_names,
            "description": f"Detected: {', '.join(class_names)}"
        })
print(f"✅ Found {len(events)} key moments")

# --- STEP 3: Generate commentary using Ollama (Mistral) ---
def generate_comment_ollama(description, timestamp):
    prompt = f"Describe this scene like an excited commentator: {description} at {timestamp:.1f} seconds."
    response = requests.post(
        "http://localhost:11434/api/chat",
        headers={"Content-Type": "application/json"},
        json={
            "model": OLLAMA_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False
        }
    )
    result = response.json()
    return result["message"]["content"].strip()

commentary = []
for i, event in enumerate(events):
    print(f"🧠 Generating text for {event['timestamp']:.1f}s...")
    try:
        text = generate_comment_ollama(event["description"], event["timestamp"])
    except Exception as e:
        print(f"⚠️ Failed to get commentary: {e}")
        text = "Exciting moment on the field!"
    commentary.append({
        "timestamp": event["timestamp"],
        "text": text
    })

# --- STEP 4: TTS with fallback padding ---
def safe_tts(tts, text, filepath):
    try:
        if len(text.strip().split()) < 4:
            text += " And the crowd goes wild."
        tts.tts_to_file(text=text, speaker="p225", file_path=filepath)
        return True
    except Exception as e:
        print(f"⚠️ Skipping TTS for text due to error: {e}")
        return False

audio_paths = []
for i, line in enumerate(commentary):
    timestamp = line["timestamp"]
    filename = os.path.join(TMP_AUDIO_FOLDER, f"line_{i}.wav")
    print(f"🔊 Generating speech for {timestamp:.1f}s")
    if safe_tts(tts, line["text"], filename):
        audio_paths.append((timestamp, filename))

# --- STEP 5: Merge audio & video with FFmpeg ---
if not audio_paths:
    print("❌ No audio generated, skipping merge.")
    exit(1)

inputs = ["-i", VIDEO_PATH]
concat_script = ""
for i, (timestamp, path) in enumerate(audio_paths):
    inputs += ["-itsoffset", str(timestamp), "-i", path]
    concat_script += f"[{i + 1}:a]"

filter_complex = f"{concat_script}concat=n={len(audio_paths)}:v=0:a=1[outa]"

command = [
    "ffmpeg", "-y", *inputs,
    "-filter_complex", filter_complex,
    "-map", "0:v", "-map", "[outa]",
    "-c:v", "copy", "-shortest", OUTPUT_VIDEO
]

print("🎬 Merging audio and video...")
subprocess.run(command)
print(f"✅ Final video saved to {OUTPUT_VIDEO}")
