import os
import cv2
import subprocess
from ultralytics import YOLO
from TTS.api import TTS
import time
import json
import requests

# --- CONFIG ---
VIDEO_PATH = "football.mp4"
FRAME_RATE = 1
TMP_AUDIO_FOLDER = "tts_audio"
OUTPUT_VIDEO = "output_with_commentary_contextual.mp4"

# --- Setup ---
os.makedirs(TMP_AUDIO_FOLDER, exist_ok=True)
model = YOLO("yolov8n.pt")  # Lightweight object detector
tts = TTS(model_name="tts_models/en/ljspeech/glow-tts", progress_bar=False)

# --- Step 1: Extract Frames ---
cap = cv2.VideoCapture(VIDEO_PATH)
fps = cap.get(cv2.CAP_PROP_FPS)
interval = int(fps // FRAME_RATE) if fps > 0 else 1
frames = []
timestamps = []
frame_id = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break
    if frame_id % interval == 0:
        frames.append(frame)
        timestamps.append(frame_id / fps)
    frame_id += 1
cap.release()
print(f"✅ Extracted {len(frames)} frames")

# --- Step 2: Object Detection ---
events = []
for i, frame in enumerate(frames):
    results = model(frame)[0]
    class_ids = results.boxes.cls.cpu().numpy().astype(int)
    class_names = [model.names[c] for c in class_ids]
    if class_names:
        events.append({
            "timestamp": timestamps[i],
            "objects": class_names,
            "description": f"Detected: {', '.join(class_names)}"
        })

print(f"✅ Found {len(events)} key moments")

# --- Step 3: Generate Football-Aware Commentary (Ollama) ---
def classify_football_event(objs):
    objs = set(objs)
    if {"person", "ball", "goalpost"}.issubset(objs):
        return "goal attempt"
    elif {"person", "ball"}.issubset(objs):
        return "dribble or pass"
    elif "goalpost" in objs:
        return "defending near goal"
    elif objs == {"person"}:
        return "running or preparing"
    else:
        return "general action"

def generate_football_prompt(objects, timestamp, event_type):
    return (
        f"You are a football commentator. At {timestamp:.1f} seconds, "
        f"a football event is occurring: {event_type}. "
        f"The objects detected are: {', '.join(objects)}. "
        "Generate an exciting and natural commentary line as if you're watching a live football game."
    )

commentary = []

for i, event in enumerate(events):
    event_type = classify_football_event(event["objects"])
    prompt = generate_football_prompt(event["objects"], event["timestamp"], event_type)

    print(f"🧠 Prompting Ollama at {event['timestamp']:.1f}s: {event_type}")

    response = requests.post(
        "http://localhost:11434/api/chat",
        headers={"Content-Type": "application/json"},
        json={
            "model": "mistral",
            "messages": [{"role": "user", "content": prompt}],
            "stream": False
        }
    )
    text = response.json()["message"]["content"].strip()

    commentary.append({
        "timestamp": event["timestamp"],
        "text": text
    })

# --- Step 4: TTS with Coqui ---
audio_paths = []
for i, line in enumerate(commentary):
    timestamp = line["timestamp"]
    filename = os.path.join(TMP_AUDIO_FOLDER, f"line_{i}.wav")

    # Pad short lines
    text = line["text"]
    if len(text.split()) < 4:
        text += " And the audience is stunned!"

    print(f"🔊 Generating speech for {timestamp:.1f}s")
    tts.tts_to_file(text=text, file_path=filename)
    audio_paths.append((timestamp, filename))

# --- Step 5: Merge Audio & Video (FFmpeg) ---
concat_script = ""
inputs = ["-i", VIDEO_PATH]
for i, (timestamp, path) in enumerate(audio_paths):
    inputs += ["-itsoffset", str(timestamp), "-i", path]
    concat_script += f"[{i + 1}:a]"

filter_complex = f"{concat_script}concat=n={len(audio_paths)}:v=0:a=1[outa]"

command = [
    "ffmpeg", "-y", *inputs,
    "-filter_complex", filter_complex,
    "-map", "0:v", "-map", "[outa]",
    "-c:v", "copy", "-shortest", OUTPUT_VIDEO
]

print("🎬 Merging audio and video...")
subprocess.run(command)
print(f"✅ Final video saved to {OUTPUT_VIDEO}")
